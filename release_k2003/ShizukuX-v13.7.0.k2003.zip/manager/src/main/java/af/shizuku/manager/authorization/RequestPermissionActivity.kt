package af.shizuku.manager.authorization

import android.app.Dialog
import android.content.pm.ApplicationInfo
import android.view.WindowManager
import android.content.pm.PackageManager
import android.os.Bundle
import android.text.method.LinkMovementMethod
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import af.shizuku.manager.Helps
import af.shizuku.manager.ShizukuSettings
import af.shizuku.manager.R
import af.shizuku.core.ui.AppActivity
import af.shizuku.manager.databinding.ConfirmationDialogBinding
import af.shizuku.manager.ktx.toHtml
import af.shizuku.manager.utils.Logger.LOGGER
import af.shizuku.manager.utils.EnvironmentUtils
import af.shizuku.manager.utils.ShizukuStateMachine
import rikka.core.res.resolveColor
import rikka.html.text.HtmlCompat
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuApiConstants.REQUEST_PERMISSION_REPLY_ALLOWED
import rikka.shizuku.ShizukuApiConstants.REQUEST_PERMISSION_REPLY_IS_ONETIME

class RequestPermissionActivity : AppActivity() {

    private lateinit var dialog: Dialog

    // Dispatches the result to the requesting app via Binder.
    // Must be called from Dispatchers.IO — dispatchPermissionConfirmationResult is a
    // synchronous Binder call; running it on Main causes ANR (SHIZUKUPLUS-21).
    private fun dispatchResult(requestUid: Int, requestPid: Int, requestCode: Int, allowed: Boolean, onetime: Boolean) {
        val data = Bundle()
        data.putBoolean(REQUEST_PERMISSION_REPLY_ALLOWED, allowed)
        data.putBoolean(REQUEST_PERMISSION_REPLY_IS_ONETIME, onetime)
        try {
            Shizuku.dispatchPermissionConfirmationResult(requestUid, requestPid, requestCode, data)
        } catch (e: Throwable) {
            LOGGER.e("dispatchPermissionConfirmationResult")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uid = intent.getIntExtra("uid", -1)
        val pid = intent.getIntExtra("pid", -1)
        val requestCode = intent.getIntExtra("requestCode", -1)
        // ai is null when the server couldn't resolve the caller via PackageManager (device/profile
        // PM-lookup gap, #391 follow-up) - previously that silently finish()'d here with no dispatch,
        // leaving the caller's requestPermission() call hanging forever. uid/pid/requestCode are
        // always present (the server only starts this activity with them set), so fall back to the
        // callingPackage label instead of dropping the request.
        val ai = androidx.core.content.IntentCompat.getParcelableExtra(intent, "applicationInfo", ApplicationInfo::class.java)
        val callingPackage = intent.getStringExtra("callingPackage")
        if (uid == -1 || pid == -1) {
            finish()
            return
        }

        lifecycleScope.launch {
            // pingBinder() is a synchronous Binder call — run on IO so the main thread
            // stays free. withTimeout only cancels at suspension points, so moving the
            // blocking call to IO is the only safe way to prevent ANR here.
            val binderReady = try {
                withTimeout(5000) {
                    while (true) {
                        if (ShizukuStateMachine.get() == ShizukuStateMachine.State.RUNNING) {
                            val alive = withContext(Dispatchers.IO) {
                    try { Shizuku.pingBinder() } catch (e: Exception) { false }
                }
                            if (alive) break
                        }
                        delay(100)
                    }
                }
                true
            } catch (e: TimeoutCancellationException) {
                LOGGER.e(e, "Binder not received or ping failed in 5s")
                false
            }

            if (isFinishing || isDestroyed) return@launch

            if (!binderReady) {
                finish()
                return@launch
            }

            // checkRemotePermission is a synchronous Binder call — run on IO
            // Auto-allow permission requests from external-relay apps when the "auto authorize"
            // toggle is on: Scene and Brevent are activated through the relay chain, and their
            // subsequent Shizuku requests should go through without a manual dialog.
            if (autoAllow(callingPackage)) {
                lifecycleScope.launch(Dispatchers.IO) {
                    dispatchResult(uid, pid, requestCode, allowed = true, onetime = false)
                }
                finish()
                return@launch
            }

            val hasSelfPermission = withContext(Dispatchers.IO) {
                try {
                    Shizuku.checkRemotePermission("android.permission.GRANT_RUNTIME_PERMISSIONS") == PackageManager.PERMISSION_GRANTED
                } catch (e: Exception) {
                    LOGGER.w(e, "checkRemotePermission failed, denying by default")
                    false
                }
            }

            if (isFinishing || isDestroyed) return@launch
            showPermissionDialog(uid, pid, requestCode, ai, callingPackage, hasSelfPermission)
        }
    }

    /**
     * Whether the calling package should be auto-allowed under the external-relay
     * "auto authorize" toggle (Scene / Brevent).
     */
    private fun autoAllow(callingPackage: String?): Boolean {
        if (!ShizukuSettings.getExternalRelayAuto()) return false
        return callingPackage == "com.omarea.vtools" || callingPackage == "me.piebridge.brevent"
    }

    private fun showPermissionDialog(uid: Int, pid: Int, requestCode: Int, ai: ApplicationInfo?, callingPackage: String?, hasSelfPermission: Boolean) {
        if (!hasSelfPermission) {
            // Can't grant — dispatch denial and show informational dialog
            lifecycleScope.launch(Dispatchers.IO) {
                dispatchResult(uid, pid, requestCode, allowed = false, onetime = true)
            }
            showSelfPermissionMissingDialog()
            return
        }

        val label = ai?.let {
            try {
                it.loadLabel(packageManager)
            } catch (e: Exception) {
                it.packageName
            }
        } ?: callingPackage ?: "Shell"

        val binding = ConfirmationDialogBinding.inflate(layoutInflater).apply {
            button1.setOnClickListener {
                // Dispatch result on IO then dismiss — keeps UI responsive while
                // the Binder call completes without blocking the main thread
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        dispatchResult(uid, pid, requestCode, allowed = true, onetime = false)
                    }
                    if (!isFinishing && !isDestroyed) dialog.dismiss()
                }
            }
            button3.setOnClickListener {
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) {
                        dispatchResult(uid, pid, requestCode, allowed = false, onetime = true)
                    }
                    if (!isFinishing && !isDestroyed) dialog.dismiss()
                }
            }
            title.text = HtmlCompat.fromHtml(
                getString(R.string.permission_warning_template, label, getString(R.string.permission_group_description))
            )
        }

        dialog = MaterialAlertDialogBuilder(this)
            .setView(binding.root)
            .setCancelable(false)
            .setOnDismissListener { finish() }
            .create()
        dialog.setCanceledOnTouchOutside(false)
        try {
            dialog.show()
        } catch (e: WindowManager.BadTokenException) {
            // Activity window detached by the time the coroutine resumed
            finish()
        }
    }

    private fun showSelfPermissionMissingDialog() {
        val icon = getDrawable(R.drawable.ic_system_icon)
        icon?.setTint(theme.resolveColor(android.R.attr.colorAccent))

        // OPPO/OnePlus (ColorOS/OxygenOS) gets a concrete, device-specific guide: the server's
        // GRANT_RUNTIME_PERMISSIONS is blocked by the proprietary permission layer, and the fix
        // (permission monitor / Disable system optimization) only takes effect after a reboot.
        val messageRes = if (EnvironmentUtils.isOppo() || EnvironmentUtils.isOnePlus()) {
            R.string.app_management_dialog_adb_is_limited_oppo
        } else {
            R.string.app_management_dialog_adb_is_limited_message
        }
        val message = if (messageRes == R.string.app_management_dialog_adb_is_limited_message) {
            getString(messageRes, Helps.ADB.get())
        } else {
            getString(messageRes)
        }

        val d = MaterialAlertDialogBuilder(this)
            .setIcon(icon)
            .setTitle("Shizuku: ${getString(R.string.app_management_dialog_adb_is_limited_title)}")
            .setMessage(
                message.toHtml(HtmlCompat.FROM_HTML_OPTION_TRIM_WHITESPACE)
            )
            .setPositiveButton(android.R.string.ok, null)
            .setOnDismissListener { finish() }
            .create()
        d.setOnShowListener {
            (it as AlertDialog).findViewById<TextView>(android.R.id.message)?.movementMethod = LinkMovementMethod.getInstance()
        }
        try {
            d.show()
        } catch (e: Throwable) {
            LOGGER.w("Failed to show permission dialog (window may be detached)", e)
        }
    }
}
