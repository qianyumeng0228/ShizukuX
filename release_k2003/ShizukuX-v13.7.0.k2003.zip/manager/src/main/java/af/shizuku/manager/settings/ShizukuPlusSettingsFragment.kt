package af.shizuku.manager.settings

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import androidx.preference.TwoStatePreference
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.html.text.toHtml
import af.shizuku.manager.R
import af.shizuku.manager.ShizukuSettings
import rikka.shizuku.Shizuku
import af.shizuku.manager.security.BiometricLock
import androidx.biometric.BiometricPrompt
import af.shizuku.manager.ShizukuSettings.Keys.*

import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import androidx.core.view.MenuProvider
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.activity.result.contract.ActivityResultContracts
import af.shizuku.manager.backup.BackupRestoreManager
import af.shizuku.manager.backup.BackupKeyUnavailableException
import af.shizuku.manager.backup.CryptoUtils
import android.security.keystore.KeyPermanentlyInvalidatedException
import javax.crypto.AEADBadTagException
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class ShizukuPlusSettingsFragment : BaseSettingsFragment() {

    override fun getTitle(): CharSequence? = getString(R.string.settings_feature_hub_title)

    // e.message is often null for keystore/cipher exceptions (#315's "Backup failed: null"), and
    // KeyPermanentlyInvalidatedException needs a message explaining it's unrecoverable rather
    // than a raw exception string (#332) - encryption self-heals from this in CryptoUtils, but
    // decryption of an existing backup genuinely can't.
    private fun backupErrorMessage(ctx: Context, prefixRes: Int, isRestore: Boolean, e: Exception): String = when (e) {
        is KeyPermanentlyInvalidatedException ->
            ctx.getString(
                if (isRestore) {
                    R.string.settings_backup_key_invalidated_restore
                } else {
                    R.string.settings_backup_key_invalidated_backup
                },
                ctx.getString(prefixRes)
            )
        // The key was destroyed (uninstall/reinstall or cleared data) — explain, don't show a raw error (#370).
        is BackupKeyUnavailableException ->
            ctx.getString(R.string.settings_backup_key_unavailable, ctx.getString(prefixRes))
        // A valid key exists but can't authenticate this ciphertext: the backup was made by a
        // different install, is corrupt, or was tampered with. GCM's tag check is exactly what
        // catches that — surface it as a clear cause instead of "AEADBadTagException" (#370).
        is AEADBadTagException ->
            ctx.getString(R.string.settings_backup_decryption_failed_install, ctx.getString(prefixRes))
        else -> ctx.getString(R.string.settings_error_with_detail, ctx.getString(prefixRes), e.message ?: e.javaClass.simpleName)
    }

    private val createPlainBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        val ctx = requireContext()
        try {
            val payload = BackupRestoreManager.createPlainBackupPayload(ctx)
            ctx.contentResolver.openOutputStream(uri)?.use { os ->
                OutputStreamWriter(os, Charsets.UTF_8).use { it.write(payload) }
            }
            Toast.makeText(ctx, R.string.settings_plain_backup_exported, Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.settings_backup_operation_failed, Toast.LENGTH_LONG).show()
        }
    }

    private val createBackupLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@registerForActivityResult
        val ctx = requireContext()
        val lock = BiometricLock(requireActivity())
        val useAuth = lock.canAuthenticate(ctx)

        if (!useAuth) {
            try {
                val cipher = CryptoUtils.getCipherForEncryption(userAuthRequired = false)
                val payload = BackupRestoreManager.createBackupPayload(ctx, cipher)
                ctx.contentResolver.openOutputStream(uri)?.use { os ->
                    OutputStreamWriter(os, Charsets.UTF_8).use { it.write(payload) }
                }
                Toast.makeText(ctx, R.string.settings_backup_exported, Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(ctx, backupErrorMessage(ctx, R.string.settings_backup_failed_prefix, false, e), Toast.LENGTH_LONG).show()
            }
            return@registerForActivityResult
        }

        try {
            val cipher = CryptoUtils.getCipherForEncryption(userAuthRequired = true)
            lock.authenticate(onSuccess = { crypto ->
                try {
                    val payload = BackupRestoreManager.createBackupPayload(ctx, crypto?.cipher ?: cipher)
                    ctx.contentResolver.openOutputStream(uri)?.use { os ->
                        OutputStreamWriter(os, Charsets.UTF_8).use { it.write(payload) }
                    }
                Toast.makeText(ctx, R.string.settings_backup_exported, Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, backupErrorMessage(ctx, R.string.settings_backup_failed_prefix, false, e), Toast.LENGTH_LONG).show()
                }
            }, onError = { errCode ->
                Toast.makeText(ctx, ctx.getString(R.string.settings_authentication_failed, errCode), Toast.LENGTH_SHORT).show()
            }, crypto = BiometricPrompt.CryptoObject(cipher))
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.settings_backup_operation_failed, Toast.LENGTH_LONG).show()
        }
    }

    private val restoreBackupLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@registerForActivityResult
        val ctx = requireContext()
        val lock = BiometricLock(requireActivity())
        val useAuth = lock.canAuthenticate(ctx)

        try {
            val payload = ctx.contentResolver.openInputStream(uri)?.use { `is` ->
                InputStreamReader(`is`, Charsets.UTF_8).readText()
            } ?: return@registerForActivityResult

            // Auto-detect format: plain (v2) backups skip encryption entirely.
            if (!BackupRestoreManager.isEncrypted(payload)) {
                try {
                    BackupRestoreManager.restoreFromPlainPayload(ctx, payload)
                    Toast.makeText(ctx, R.string.settings_backup_restored_restart, Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, R.string.settings_restore_operation_failed, Toast.LENGTH_LONG).show()
                }
                return@registerForActivityResult
            }

            val iv = BackupRestoreManager.extractIv(payload)

            if (!useAuth) {
                try {
                    val cipher = CryptoUtils.getCipherForDecryption(iv, userAuthRequired = false)
                    BackupRestoreManager.restoreFromPayload(ctx, payload, cipher)
                    Toast.makeText(ctx, R.string.settings_backup_restored_restart, Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, backupErrorMessage(ctx, R.string.settings_restore_failed_prefix, true, e), Toast.LENGTH_LONG).show()
                }
                return@registerForActivityResult
            }

            val cipher = CryptoUtils.getCipherForDecryption(iv, userAuthRequired = true)
            lock.authenticate(onSuccess = { crypto ->
                try {
                    BackupRestoreManager.restoreFromPayload(ctx, payload, crypto?.cipher ?: cipher)
                    Toast.makeText(ctx, R.string.settings_backup_restored_restart, Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(ctx, backupErrorMessage(ctx, R.string.settings_restore_failed_prefix, true, e), Toast.LENGTH_LONG).show()
                }
            }, onError = { errCode ->
                Toast.makeText(ctx, ctx.getString(R.string.settings_authentication_failed, errCode), Toast.LENGTH_SHORT).show()
            }, crypto = BiometricPrompt.CryptoObject(cipher))
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.settings_restore_operation_failed, Toast.LENGTH_LONG).show()
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh Dhizuku device-owner status when returning to this page.
        // The status can change externally (e.g. device owner transferred from
        // another app like Dhizuku), and onCreatePreferences only runs once.
        val dhizukuPref = findPreference<TwoStatePreference>(KEY_DHIZUKU_MODE)
        if (dhizukuPref != null) {
            updateDhizukuDeviceOwnerStatus(dhizukuPref)
        }
    }

    override fun onCreateSettingsPreferences(savedInstanceState: Bundle?, rootKey: String?) {
        if (!isAdded) return
        setPreferencesFromResource(R.xml.settings_shizuku_plus, rootKey)

        ShizukuSettings.syncAllPlusFeaturesToServer()

        // Setup menu for 'Learn more' icon
        activity?.addMenuProvider(object : MenuProvider {
            override fun onCreateMenu(menu: Menu, menuInflater: MenuInflater) {
                if (!isAdded) return
                menu.clear()
                menuInflater.inflate(R.menu.plus_settings_menu, menu)
            }

            override fun onMenuItemSelected(menuItem: MenuItem): Boolean {
                if (!isAdded) return false
                if (menuItem.itemId == R.id.action_plus_help) {
                    showGeneralHelpDialog()
                    return true
                }
                return false
            }
        }, this)

        val dhizukuPref = requireNotNull(findPreference<TwoStatePreference>(KEY_DHIZUKU_MODE))
        dhizukuPref.isChecked = ShizukuSettings.isDhizukuModeEnabled()
        updateDhizukuDeviceOwnerStatus(dhizukuPref)
        dhizukuPref.setOnPreferenceClickListener {
            val ctx = context ?: return@setOnPreferenceClickListener true
            if (!isDeviceOwnerActive(ctx)) {
                showDhizukuSetupDialog(ctx)
                return@setOnPreferenceClickListener true
            }
            false // let the normal toggle happen
        }
        dhizukuPref.setOnPreferenceChangeListener { _, newValue ->
            if (newValue is Boolean) {
                val ctx = context ?: return@setOnPreferenceChangeListener false
                // If trying to enable but not device owner, show setup dialog instead of toggling
                if (newValue && !isDeviceOwnerActive(ctx)) {
                    showDhizukuSetupDialog(ctx)
                    return@setOnPreferenceChangeListener false
                }
                ShizukuSettings.setDhizukuModeEnabled(newValue)
                maybePromptRestart(KEY_DHIZUKU_MODE, newValue) {
                    dhizukuPref.isChecked = newValue
                }
            }
            true
        }

        // Clear Device Owner button — only visible when app holds DO status
        val clearDoPref = findPreference<Preference>("clear_device_owner")
        clearDoPref?.isVisible = isDeviceOwnerActive(requireContext())
        clearDoPref?.setOnPreferenceClickListener {
            val ctx = context ?: return@setOnPreferenceClickListener true
            showClearDeviceOwnerDialog(ctx)
            true
        }

        // Transfer Device Owner button — only visible when app holds DO status
        val transferDoPref = findPreference<Preference>("transfer_device_owner")
        transferDoPref?.isVisible = isDeviceOwnerActive(requireContext())
        transferDoPref?.setOnPreferenceClickListener {
            val ctx = context ?: return@setOnPreferenceClickListener true
            showTransferDeviceOwnerDialog(ctx)
            true
        }

        // Dhizuku App Management — list apps that may use the Dhizuku (device-owner) API
        findPreference<Preference>("dhizuku_app_management")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), DhizukuAppManagementActivity::class.java))
            true
        }

        // Device Owner Tools - Screen Capture Lockdown
        findPreference<TwoStatePreference>("dhizuku_disable_screencap")?.setOnPreferenceChangeListener { _, newValue ->
            val enabled = newValue as? Boolean ?: false
            val ctx = context ?: return@setOnPreferenceChangeListener false
            try {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val admin = ComponentName(ctx, af.shizuku.manager.admin.DhizukuAdminReceiver::class.java)
                dpm.setScreenCaptureDisabled(admin, enabled)
                Toast.makeText(
                    ctx,
                    if (enabled) R.string.settings_screen_capture_disabled else R.string.settings_screen_capture_enabled,
                    Toast.LENGTH_SHORT
                ).show()
                true
            } catch (e: Exception) {
                Toast.makeText(ctx, R.string.settings_device_owner_required, Toast.LENGTH_LONG).show()
                false
            }
        }

        // Device Owner Tools - USB Data Lockdown
        findPreference<TwoStatePreference>("dhizuku_disallow_usb")?.setOnPreferenceChangeListener { _, newValue ->
            val enabled = newValue as? Boolean ?: false
            val ctx = context ?: return@setOnPreferenceChangeListener false
            try {
                val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                val admin = ComponentName(ctx, af.shizuku.manager.admin.DhizukuAdminReceiver::class.java)
                if (enabled) {
                    dpm.addUserRestriction(admin, android.os.UserManager.DISALLOW_USB_FILE_TRANSFER)
                    Toast.makeText(ctx, R.string.settings_usb_data_locked, Toast.LENGTH_SHORT).show()
                } else {
                    dpm.clearUserRestriction(admin, android.os.UserManager.DISALLOW_USB_FILE_TRANSFER)
                    Toast.makeText(ctx, R.string.settings_usb_data_unlocked, Toast.LENGTH_SHORT).show()
                }
                true
            } catch (e: Exception) {
                Toast.makeText(ctx, R.string.settings_device_owner_required, Toast.LENGTH_LONG).show()
                false
            }
        }

        // Device Owner Tools - App Freezing
        findPreference<Preference>("dhizuku_suspended_packages")?.setOnPreferenceChangeListener { _, newValue ->
            val packagesStr = newValue as? String ?: ""
            val packagesList = if (packagesStr.isBlank()) emptyList() else packagesStr.split(",").map { it.trim() }
            val ctx = context ?: return@setOnPreferenceChangeListener false
            // getInstalledPackages() + setPackagesSuspended() are both real IPCs (PackageManager /
            // DevicePolicyManager); do them off the main thread rather than blocking this
            // preference-change callback like the now-fixed RootCompatibilityActivity.buildItems().
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
                    val admin = ComponentName(ctx, af.shizuku.manager.admin.DhizukuAdminReceiver::class.java)
                    val pm = ctx.packageManager
                    val installed = pm.getInstalledPackages(0).map { it.packageName }.toSet()

                    // Clear any existing suspensions first
                    val toUnsuspend = installed.toMutableList()
                    dpm.setPackagesSuspended(admin, toUnsuspend.toTypedArray(), false)

                    // Set chosen suspensions
                    var message: String? = null
                    if (packagesList.isNotEmpty()) {
                        val toSuspend = packagesList.filter { installed.contains(it) }
                        val failed = dpm.setPackagesSuspended(admin, toSuspend.toTypedArray(), true)
                        message = if (failed.isNotEmpty()) {
                            ctx.getString(R.string.settings_frozen_apps_failed, failed.joinToString())
                        } else {
                            ctx.getString(R.string.settings_frozen_apps_count, toSuspend.size)
                        }
                    }
                    withContext(Dispatchers.Main) {
                        message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(ctx, R.string.settings_device_owner_required, Toast.LENGTH_LONG).show()
                    }
                }
            }
            true
        }

        val customApiPref = requireNotNull(findPreference<TwoStatePreference>(KEY_CUSTOM_API_ENABLED))
        customApiPref.isChecked = ShizukuSettings.isCustomApiEnabled()
        customApiPref.setOnPreferenceChangeListener { _, newValue ->
            if (newValue is Boolean) {
                maybePromptRestart(KEY_CUSTOM_API_ENABLED, newValue) {
                    ShizukuSettings.setCustomApiEnabled(newValue)
                    customApiPref.isChecked = newValue
                    ShizukuSettings.syncAllPlusFeaturesToServer()
                    updateAllPlusFeatureDependencies()
                }
            }
            false
        }

        val backupSettingsPref = findPreference<Preference>("backup_settings")
        backupSettingsPref?.setOnPreferenceClickListener {
            val dateStr = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())
            MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.settings_export_backup_title)
                .setItems(arrayOf(
                    getString(R.string.settings_encrypted_backup_option),
                    getString(R.string.settings_plain_backup_option)
                )) { _, which ->
                    try {
                        when (which) {
                            0 -> createBackupLauncher.launch("ShizukuX_Settings_$dateStr.json")
                            1 -> createPlainBackupLauncher.launch("ShizukuX_Settings_plain_$dateStr.json")
                        }
                    } catch (e: android.content.ActivityNotFoundException) {
                        Toast.makeText(requireContext(), R.string.settings_no_file_manager_save, Toast.LENGTH_LONG).show()
                    }
                }
                .show()
            true
        }

        val restoreSettingsPref = findPreference<Preference>("restore_settings")
        restoreSettingsPref?.setOnPreferenceClickListener {
            try {
                restoreBackupLauncher.launch(arrayOf("application/json", "*/*"))
            } catch (e: android.content.ActivityNotFoundException) {
                Toast.makeText(requireContext(), R.string.settings_no_file_manager_open, Toast.LENGTH_LONG).show()
            }
            true
        }

        val hideDisabledPref = findPreference<TwoStatePreference>("hide_disabled_plus_features")
        hideDisabledPref?.isChecked = ShizukuSettings.isHideDisabledPlusFeaturesEnabled()
        hideDisabledPref?.setOnPreferenceChangeListener { _, newValue ->
            if (newValue is Boolean) {
                ShizukuSettings.setHideDisabledPlusFeaturesEnabled(newValue)
                updateAllPlusFeatureDependencies()
            }
            true
        }

        val plusKeys = listOf(
            "shell_interceptor_enabled" to "shell_interceptor",
            "avf_manager_enabled" to "avf_manager",
            "storage_proxy_enabled" to "storage_proxy",
            "continuity_bridge_enabled" to "continuity_bridge",
            "ai_core_plus_enabled" to "ai_core_plus",
            "ai_core_master_enabled" to "ai_core_master",
            "npu_acceleration_enabled" to "npu_acceleration",
            "native_window_crawler_enabled" to "native_window_crawler",
            "ai_core_experimental_enabled" to "ai_core_experimental",
            "window_manager_plus_enabled" to "window_manager_plus",
            "overlay_manager_plus_enabled" to "overlay_manager_plus",
            "network_governor_plus_enabled" to "network_governor_plus",
            "activity_manager_plus_enabled" to "activity_manager_plus",
            "shadow_binder_enabled" to "shadow_binder",
            "binder_firewall_enabled" to "binder_firewall",
            "binder_logging_enabled" to "binder_logging",
            "samsung_system_uid_escalation_enabled" to "samsung_system_uid_escalation",
            "software_keystore_fallback_enabled" to "software_keystore_fallback"
        )
        val experimentalKeys = setOf(
            "avf_manager_enabled",
            "ai_core_master_enabled",
            "npu_acceleration_enabled",
            "native_window_crawler_enabled",
            "ai_core_experimental_enabled",
            "vector_enabled",
            "experimental_root_compat",
            "spoof_device_enabled",
            "samsung_system_uid_escalation_enabled"
        )

        plusKeys.forEach { (prefKey, featureName) ->
            findPreference<TwoStatePreference>(prefKey)?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as? Boolean ?: false
                if (enabled && experimentalKeys.contains(prefKey)) {
                    showExperimentalWarning(prefKey) {
                        preferenceManager.sharedPreferences?.edit()?.putBoolean(prefKey, true)?.apply()
                        // Cascade child state BEFORE syncing so the server sees a consistent
                        // parent+child snapshot (disabling a parent force-unchecks children).
                        updatePlusFeatureDependency(prefKey, true)
                        ShizukuSettings.syncAllPlusFeaturesToServer()
                    }
                    false // Handle manually after dialog
                } else {
                    preferenceManager.sharedPreferences?.edit()?.putBoolean(prefKey, enabled)?.apply()
                    updatePlusFeatureDependency(prefKey, enabled)
                    ShizukuSettings.syncAllPlusFeaturesToServer()
                    true
                }
            }
        }

        findPreference<Preference>("spoof_target")?.setOnPreferenceChangeListener { _, newValue ->
            preferenceManager.sharedPreferences?.edit()?.putString("spoof_target", newValue as String)?.apply()
            ShizukuSettings.syncAllPlusFeaturesToServer()
            true
        }

        findPreference<Preference>(KEY_SHADOW_BINDER_HIDDEN_PACKAGES)?.setOnPreferenceChangeListener { _, _ ->
            ShizukuSettings.syncAllPlusFeaturesToServer()
            true
        }

        findPreference<Preference>("ai_core_plus_enabled")?.setOnPreferenceChangeListener { _, newValue ->
            val enabled = newValue as? Boolean ?: false
            if (enabled) {
                val lock = BiometricLock(requireActivity())
                if (lock.canAuthenticate(requireContext())) {
                    lock.authenticate({
                        ShizukuSettings.setAICorePlusEnabled(true)
                        ShizukuSettings.syncAllPlusFeaturesToServer()
                        activity?.runOnUiThread {
                            findPreference<TwoStatePreference>("ai_core_plus_enabled")?.isChecked = true
                            updatePlusFeatureDependency("ai_core_plus_enabled", true)
                        }
                    }, { _ -> /* Ignore or show toast */ })
                    return@setOnPreferenceChangeListener false
                }
            }
            // fallback / standard or disabling
            preferenceManager.sharedPreferences?.edit()?.putBoolean("ai_core_plus_enabled", enabled)?.apply()
            // Cascade child state BEFORE syncing: disabling ai_core_plus force-unchecks the
            // AI sub-features, and the server gates NPU/window/automation on those child flags
            // (not on ai_core_plus), so they must be false in prefs before the sync runs.
            updatePlusFeatureDependency("ai_core_plus_enabled", enabled)
            ShizukuSettings.syncAllPlusFeaturesToServer()
            true
        }

        // Initialize all preference dependencies
        updateAllPlusFeatureDependencies()

        // Check for integrated apps and update summaries
        checkAppIntegrations()

        // External relay authorization entry: opens the dedicated management screen where the
        // user can manage relayed apps (Scene today, more apps later).
        findPreference<Preference>("external_relay_manager")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), ExternalRelayActivity::class.java))
            true
        }
    }

    private fun isDeviceOwnerActive(ctx: Context): Boolean {
        return try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            dpm.isDeviceOwnerApp(ctx.packageName) || dpm.isProfileOwnerApp(ctx.packageName)
        } catch (e: Exception) {
            false
        }
    }

    private fun updateDhizukuDeviceOwnerStatus(pref: TwoStatePreference) {
        val ctx = context ?: return
        val active = isDeviceOwnerActive(ctx)
        val statusLine = if (active)
            getString(R.string.dhizuku_status_active)
        else
            getString(R.string.dhizuku_status_not_set)
        val baseSummary = getString(R.string.settings_dhizuku_mode_summary)
        pref.summary = "$statusLine\n\n$baseSummary"
        // If device owner is active, ensure Dhizuku mode is enabled (they go hand-in-hand)
        if (active && !pref.isChecked) {
            pref.isChecked = true
            ShizukuSettings.setDhizukuModeEnabled(true)
        }
        // Show/hide the Clear Owner and Transfer Owner buttons based on active status
        findPreference<Preference>("clear_device_owner")?.isVisible = active
        findPreference<Preference>("transfer_device_owner")?.isVisible = active
    }

    private fun showClearDeviceOwnerDialog(ctx: Context) {
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.dhizuku_clear_owner_title)
            .setMessage(R.string.dhizuku_clear_owner_message)
            .setPositiveButton(R.string.dhizuku_clear_owner_confirm) { _, _ ->
                clearDeviceOwner(ctx)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun clearDeviceOwner(ctx: Context) {
        try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (dpm.isDeviceOwnerApp(ctx.packageName)) {
                dpm.clearDeviceOwnerApp(ctx.packageName)
            } else if (dpm.isProfileOwnerApp(ctx.packageName)) {
                val admin = android.content.ComponentName(ctx, af.shizuku.manager.admin.DhizukuAdminReceiver::class.java)
                dpm.clearProfileOwner(admin)
            }
            Toast.makeText(ctx, R.string.dhizuku_clear_owner_success, Toast.LENGTH_LONG).show()
            // Refresh the UI to reflect the change
            val dhizukuPref = findPreference<TwoStatePreference>(KEY_DHIZUKU_MODE)
            if (dhizukuPref != null) {
                ShizukuSettings.setDhizukuModeEnabled(false)
                dhizukuPref.isChecked = false
                updateDhizukuDeviceOwnerStatus(dhizukuPref)
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, R.string.dhizuku_clear_owner_failure, Toast.LENGTH_LONG).show()
        }
    }

    private fun showDhizukuSetupDialog(ctx: Context) {
        // applicationId (xyz.shizuku.extra.api) differs from namespace (af.shizuku.manager),
        // so the full class name must be explicit rather than using the shorthand dot notation.
        val command = "adb shell dpm set-device-owner " +
            "${ctx.packageName}/af.shizuku.manager.admin.DhizukuAdminReceiver"
        val dpmCommand = "dpm set-device-owner " +
            "${ctx.packageName}/af.shizuku.manager.admin.DhizukuAdminReceiver"
        lateinit var setupDialog: androidx.appcompat.app.AlertDialog
        setupDialog = MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.dhizuku_setup_title)
            .setMessage(getString(R.string.dhizuku_setup_message, command))
            .setPositiveButton(R.string.dhizuku_setup_via_shizukux) { _, _ ->
                // Dismiss the setup dialog first, then show progress and activate
                setupDialog.dismiss()
                activateViaShizukuX(ctx, dpmCommand)
            }
            .setNeutralButton(R.string.dhizuku_setup_command_line) { _, _ ->
                val clipboard = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("dpm command", command))
                Toast.makeText(ctx, R.string.dhizuku_setup_copied, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        setupDialog.show()
    }

    private fun activateViaShizukuX(ctx: Context, command: String) {
        // Check if ShizukuX service is running
        if (!Shizuku.pingBinder()) {
            Toast.makeText(ctx, R.string.dhizuku_setup_shizukux_not_running, Toast.LENGTH_LONG).show()
            return
        }
        val progressDialog = MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.dhizuku_setup_running)
            .setCancelable(false)
            .create()
        progressDialog.show()
        lifecycleScope.launch(Dispatchers.IO) {
            val result = try {
                // Execute dpm command via ShizukuX's shell privilege (inherits shell/ADB UID,
                // which has permission to run dpm set-device-owner).
                // Explicit environment variables are required because Shizuku.newProcess may not
                // inherit the full shell environment (PATH, HOME, ANDROID_ROOT, etc.).
                val env = arrayOf(
                    "PATH=/system/bin:/system/xbin:/vendor/bin",
                    "HOME=/data/local/tmp",
                    "ANDROID_ROOT=/system",
                    "ANDROID_DATA=/data",
                    "EXTERNAL_STORAGE=/sdcard",
                    "TMPDIR=/data/local/tmp"
                )
                // Use full path to dpm to ensure command is found
                val fullCommand = "/system/bin/dpm set-device-owner " +
                    "${ctx.packageName}/af.shizuku.manager.admin.DhizukuAdminReceiver"
                val process = Shizuku.newProcess(
                    arrayOf("/system/bin/sh", "-c", fullCommand),
                    env,
                    "/data/local/tmp"
                )
                val stdout = process.inputStream.bufferedReader().readText()
                val stderr = process.errorStream.bufferedReader().readText()
                val exitCode = process.waitFor()
                if (exitCode == 0 && (stdout + stderr).contains("Success")) {
                    Result.success(Unit)
                } else {
                    val error = (stdout + stderr).trim().ifEmpty { "exit code $exitCode" }
                    Result.failure(Exception(error))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
            withContext(Dispatchers.Main) {
                progressDialog.dismiss()
                if (result.isSuccess) {
                    Toast.makeText(ctx, R.string.dhizuku_setup_shizukux_success, Toast.LENGTH_LONG).show()
                    val dhizukuPref = findPreference<TwoStatePreference>(KEY_DHIZUKU_MODE)
                    if (dhizukuPref != null) {
                        ShizukuSettings.setDhizukuModeEnabled(true)
                        dhizukuPref.isChecked = true
                        updateDhizukuDeviceOwnerStatus(dhizukuPref)
                    }
                } else {
                    val error = result.exceptionOrNull()?.message ?: "Unknown error"
                    Toast.makeText(ctx, getString(R.string.dhizuku_setup_shizukux_failure, error), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun isDeviceRooted(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    private fun runDeviceOwnerAsRoot(ctx: Context, command: String) {
        if (!isDeviceRooted()) {
            Toast.makeText(ctx, R.string.dhizuku_setup_root_required, Toast.LENGTH_LONG).show()
            return
        }
        val progressDialog = MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.dhizuku_setup_running)
            .setCancelable(false)
            .create()
        progressDialog.show()
        lifecycleScope.launch(Dispatchers.IO) {
            val result = try {
                val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
                val stdout = process.inputStream.bufferedReader().readText()
                val stderr = process.errorStream.bufferedReader().readText()
                val exitCode = process.waitFor()
                if (exitCode == 0 && (stdout + stderr).contains("Success")) {
                    Result.success(Unit)
                } else {
                    val error = (stdout + stderr).trim().ifEmpty { "exit code $exitCode" }
                    Result.failure(Exception(error))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
            withContext(Dispatchers.Main) {
                progressDialog.dismiss()
                if (result.isSuccess) {
                    Toast.makeText(ctx, R.string.dhizuku_setup_root_success, Toast.LENGTH_LONG).show()
                    val dhizukuPref = findPreference<TwoStatePreference>(KEY_DHIZUKU_MODE)
                    if (dhizukuPref != null) {
                        ShizukuSettings.setDhizukuModeEnabled(true)
                        dhizukuPref.isChecked = true
                        updateDhizukuDeviceOwnerStatus(dhizukuPref)
                    }
                } else {
                    val error = result.exceptionOrNull()?.message ?: "Unknown error"
                    Toast.makeText(ctx, getString(R.string.dhizuku_setup_root_failure, error), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun activateViaDhizuku(ctx: Context) {
        val dhizukuPackage = "com.rosan.dhizuku"
        val intent = ctx.packageManager.getLaunchIntentForPackage(dhizukuPackage)
        if (intent == null) {
            MaterialAlertDialogBuilder(ctx)
                .setTitle(R.string.dhizuku_setup_via_dhizuku)
                .setMessage(R.string.dhizuku_setup_dhizuku_not_installed)
                .setPositiveButton(android.R.string.ok, null)
                .show()
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        Toast.makeText(ctx, R.string.dhizuku_setup_dhizuku_launch, Toast.LENGTH_SHORT).show()
    }

    private fun showTransferDeviceOwnerDialog(ctx: Context) {
        if (!isDeviceOwnerActive(ctx)) {
            Toast.makeText(ctx, R.string.dhizuku_transfer_not_owner, Toast.LENGTH_LONG).show()
            return
        }
        // Scan all apps that declare a DeviceAdminReceiver via the DEVICE_ADMIN_ENABLED action.
        val pm = ctx.packageName
        val candidates = mutableListOf<Pair<String, android.content.ComponentName>>()
        val seenPackages = mutableSetOf<String>()
        try {
            val intent = android.content.Intent("android.app.action.DEVICE_ADMIN_ENABLED")
            val receivers = ctx.packageManager.queryBroadcastReceivers(intent, 0)
            android.util.Log.d("ShizukuXTransfer", "queryBroadcastReceivers returned ${receivers.size} receivers")
            for (resolveInfo in receivers) {
                val activityInfo = resolveInfo.activityInfo ?: continue
                val packageName = activityInfo.packageName
                android.util.Log.d("ShizukuXTransfer", "found receiver: $packageName/${activityInfo.name}")
                if (packageName == pm) continue // skip self
                if (seenPackages.contains(packageName)) continue // dedupe by package: some apps declare multiple DPC receivers
                seenPackages.add(packageName)
                val name = activityInfo.name
                val appInfo = activityInfo.applicationInfo
                val label = appInfo?.loadLabel(ctx.packageManager)?.toString()
                    ?: activityInfo.loadLabel(ctx.packageManager)?.toString()
                    ?: packageName
                val component = android.content.ComponentName(packageName, name)
                candidates.add(label to component)
            }
        } catch (e: Exception) {
            android.util.Log.e("ShizukuXTransfer", "Exception scanning", e)
        }
        android.util.Log.d("ShizukuXTransfer", "candidates size: ${candidates.size}")
        if (candidates.isEmpty()) {
            Toast.makeText(ctx, R.string.dhizuku_transfer_no_targets, Toast.LENGTH_LONG).show()
            return
        }
        val labels = candidates.map { it.first }.toTypedArray()
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.dhizuku_transfer_title)
            .setItems(labels) { _, which ->
                val (label, component) = candidates[which]
                confirmTransfer(ctx, label, component)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmTransfer(ctx: Context, label: String, target: android.content.ComponentName) {
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        MaterialAlertDialogBuilder(ctx)
            .setTitle(R.string.dhizuku_transfer_confirm_title)
            .setMessage(getString(R.string.dhizuku_transfer_confirm_message, label))
            .setPositiveButton(android.R.string.ok) { _, _ ->
                try {
                    val admin = android.content.ComponentName(ctx, af.shizuku.manager.admin.DhizukuAdminReceiver::class.java)
                    dpm.transferOwnership(admin, target, null)
                    Toast.makeText(ctx, getString(R.string.dhizuku_transfer_success, label), Toast.LENGTH_LONG).show()
                    // Update UI: ShizukuX is no longer device owner
                    val dhizukuPref = findPreference<TwoStatePreference>(KEY_DHIZUKU_MODE)
                    if (dhizukuPref != null) {
                        ShizukuSettings.setDhizukuModeEnabled(false)
                        dhizukuPref.isChecked = false
                        updateDhizukuDeviceOwnerStatus(dhizukuPref)
                    }
                } catch (e: Exception) {
                    val error = e.message ?: e.javaClass.simpleName
                    android.util.Log.i("ShizukuXTransfer", "transferOwnership FAILED: pkg=" + ctx.packageName + " target=" + target + " ex=" + e.javaClass.name + " msg=" + error, e)
                    Toast.makeText(ctx, getString(R.string.dhizuku_transfer_failure, error), Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun showGeneralHelpDialog() {
        val context = context ?: return
        MaterialAlertDialogBuilder(context)
            .setTitle(R.string.settings_shizuku_plus_features)
            .setMessage(getString(R.string.help_general_plus_summary).toHtml())
            .setPositiveButton(android.R.string.ok, null)
            .show()
    }

    private fun showExperimentalWarning(prefKey: String, onConfirm: () -> Unit) {
        val context = context ?: return
        MaterialAlertDialogBuilder(context)
            .setTitle(R.string.settings_experimental_warning_title)
            .setMessage(R.string.settings_experimental_warning_message)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val pref = findPreference<TwoStatePreference>(prefKey)
                pref?.isChecked = true
                onConfirm()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun checkAppIntegrations() {
        val integrations = mapOf(
            "continuity_bridge_enabled" to listOf(
                "com.arlosoft.macrodroid" to "MacroDroid"
            ),
            "activity_manager_plus_enabled" to listOf(
                "com.arlosoft.macrodroid" to "MacroDroid",
                "net.dinglisch.android.taskerm" to "Tasker"
            ),
            "window_manager_plus_enabled" to listOf(
                "com.arlosoft.macrodroid" to "MacroDroid",
                "com.isaiasmatewos.taskbar" to "Taskbar"
            ),
            "overlay_manager_plus_enabled" to listOf(
                "project.vivid.hex.nx" to "Hex Installer",
                "tk.wasdennnoch.substratumlite" to "Substratum Lite"
            ),
            "network_governor_plus_enabled" to listOf(
                "dev.ukanth.ufirewall" to "AFWall+"
            ),
            "storage_proxy_enabled" to listOf(
                "com.machiav3lli.neo_backup" to "Neo Backup",
                "eu.darken.sdm" to "SD Maid",
                "eu.darken.sdmse" to "SD Maid SE"
            ),
            "root_magisk_mocking_enabled" to listOf(
                "com.topjohnwu.magisk" to "Magisk Manager"
            )
        )

        val pm = (context ?: return).packageManager
        lifecycleScope.launch(Dispatchers.IO) {
            val found = integrations.mapValues { (_, apps) ->
                apps.find { (pkg, _) ->
                    try { pm.getPackageInfo(pkg, 0); true } catch (e: Exception) { false }
                }
            }
            launch(Dispatchers.Main) {
                found.forEach { (prefKey, foundApp) ->
                    if (foundApp != null) {
                        findPreference<PlusFeaturePreference>(prefKey)?.apply {
                            setIntegration(foundApp.first, foundApp.second)
                            val originalSummary = summary
                            summary = getString(R.string.settings_plus_app_found, foundApp.second) + "\n\n" + originalSummary
                        }
                    }
                }
            }
        }
    }

    private fun updateAllPlusFeatureDependencies() {
        val customApiEnabled = ShizukuSettings.isCustomApiEnabled()
        val hideDisabled = ShizukuSettings.isHideDisabledPlusFeaturesEnabled()

        // Update all preferences that depend on custom_api_enabled
        updatePreferenceDependency("shell_interceptor_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("avf_manager_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("storage_proxy_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("continuity_bridge_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("ai_core_plus_enabled", customApiEnabled, hideDisabled)
        val aiCoreExtraEnabled = ShizukuSettings.isAICorePlusEnabled() && customApiEnabled
        updatePreferenceDependency("ai_core_master_enabled", aiCoreExtraEnabled, hideDisabled)
        updatePreferenceDependency("ai_core_experimental_enabled", aiCoreExtraEnabled, hideDisabled)
        val aiCoreMasterEnabled = ShizukuSettings.isAiCoreMasterEnabled() && aiCoreExtraEnabled
        updatePreferenceDependency("npu_acceleration_enabled", aiCoreMasterEnabled, hideDisabled)
        updatePreferenceDependency("native_window_crawler_enabled", aiCoreMasterEnabled, hideDisabled)
        updatePreferenceDependency("window_manager_plus_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("network_governor_plus_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("activity_manager_plus_enabled", customApiEnabled, hideDisabled)

        // Binder firewall & the external-relay subcategory live inside the collapsible
        // connectivity category. When that category starts collapsed, updateChildren() hides
        // every child; these two are not covered by the dependency list above, so restore
        // their visibility here (Scene relay does not require the enhanced API).
        updatePreferenceDependency("binder_firewall_enabled", customApiEnabled, hideDisabled)
        updatePreferenceDependency("category_external_relay", true, hideDisabled)

        // These also depend on window_manager_plus_enabled
        val windowManagerExtraEnabled = ShizukuSettings.isWindowManagerPlusEnabled() && customApiEnabled
        updatePreferenceDependency("overlay_manager_plus_enabled", windowManagerExtraEnabled, hideDisabled)

        // Force RecyclerView to recalculate layout after hiding/showing items.
        // Guard: PreferenceFragmentCompat.getListView() throws (not returns null) before
        // onCreateView completes, so the safe-call (?.) does NOT protect us — use
        // Fragment.getView() which correctly returns null when the view isn't ready.
        view?.post {
            if (isAdded && view != null) {
                try {
                    listView.requestLayout()
                    listView.invalidate()
                } catch (e: IllegalStateException) {
                    // Fragment view was destroyed between post() scheduling and execution
                }
            }
        }
    }

    private fun updatePreferenceDependency(prefKey: String, parentEnabled: Boolean, hideIfDisabled: Boolean = false) {
        findPreference<Preference>(prefKey)?.apply {
            isEnabled = parentEnabled
            if (this is TwoStatePreference && !parentEnabled) {
                isChecked = false
            }
            isVisible = if (hideIfDisabled) parentEnabled else true
        }
    }

    private fun updatePlusFeatureDependency(prefKey: String, newValue: Boolean) {
        val hideDisabled = ShizukuSettings.isHideDisabledPlusFeaturesEnabled()
        val customApiEnabled = ShizukuSettings.isCustomApiEnabled()
        when (prefKey) {
            "window_manager_plus_enabled" -> {
                updatePreferenceDependency("overlay_manager_plus_enabled", newValue && customApiEnabled, hideDisabled)
            }
            "ai_core_plus_enabled" -> {
                val active = newValue && customApiEnabled
                updatePreferenceDependency("ai_core_master_enabled", active, hideDisabled)
                updatePreferenceDependency("ai_core_experimental_enabled", active, hideDisabled)
                val masterActive = ShizukuSettings.isAiCoreMasterEnabled() && active
                updatePreferenceDependency("npu_acceleration_enabled", masterActive, hideDisabled)
                updatePreferenceDependency("native_window_crawler_enabled", masterActive, hideDisabled)
            }
            "ai_core_master_enabled" -> {
                val aiCoreExtraActive = ShizukuSettings.isAICorePlusEnabled() && customApiEnabled
                val active = newValue && aiCoreExtraActive
                updatePreferenceDependency("npu_acceleration_enabled", active, hideDisabled)
                updatePreferenceDependency("native_window_crawler_enabled", active, hideDisabled)
            }
        }
    }
}
