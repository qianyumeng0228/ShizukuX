package af.shizuku.manager.settings

import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.TwoStatePreference
import af.shizuku.manager.R
import af.shizuku.manager.ShizukuSettings
import af.shizuku.manager.ShizukuSettings.Keys.*
import af.shizuku.manager.app.ThemeHelper
import af.shizuku.manager.ktx.toHtml
import af.shizuku.manager.utils.CustomTabsHelper
import rikka.core.util.ResourceUtils
import rikka.material.app.LocaleDelegate
import af.shizuku.manager.ShizukuLocales
import java.util.Locale

class PersonalizationSettingsFragment : BaseSettingsFragment() {

    private fun applyTheme(requiresRecreate: Boolean = false) {
        if (requiresRecreate) {
            (activity as? af.shizuku.core.ui.AppActivity)?.recreateWithoutTransition()
        } else {
            (activity as? SettingsActivity)?.onThemeChanged()
        }
    }

    override fun getTitle(): CharSequence? = getString(R.string.settings_category_appearance)

    private var colorThemeCategory: CollapsiblePreferenceCategory? = null
    private lateinit var nightModePreference: IntegerSimpleMenuPreference
    private lateinit var blackNightThemePreference: TwoStatePreference
    private lateinit var useSystemColorPreference: TwoStatePreference
    private lateinit var customAccentPreference: Preference
    private lateinit var languagePreference: ListPreference
    private lateinit var translationPreference: Preference
    private lateinit var expressiveShapesPreference: TwoStatePreference
    private lateinit var expressiveAnimationsPreference: TwoStatePreference
    private lateinit var iconStylePreference: ListPreference
    private lateinit var iconColorModePreference: Preference
    private lateinit var shapeStylePreference: ListPreference
    private lateinit var animationIntensityPreference: ListPreference
    private lateinit var edgeToEdgePreference: TwoStatePreference
    private lateinit var blurUiPreference: TwoStatePreference
    private lateinit var oneUiThemePreference: TwoStatePreference
    private lateinit var wallpaperThemePreference: ListPreference

    override fun onCreateSettingsPreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.settings_personalization, rootKey)
        val context = requireContext()

        // 1. Theme and Color Controls
        colorThemeCategory = findPreference("category_color_theme")
        nightModePreference = requireNotNull(findPreference(KEY_NIGHT_MODE))
        blackNightThemePreference = requireNotNull(findPreference(KEY_BLACK_NIGHT_THEME))
        useSystemColorPreference = requireNotNull(findPreference(KEY_USE_SYSTEM_COLOR))
        customAccentPreference = requireNotNull(findPreference("custom_accent"))
        wallpaperThemePreference = requireNotNull(findPreference(KEY_WALLPAPER_THEME))

        nightModePreference.apply {
            value = ShizukuSettings.getNightMode()
            setOnPreferenceChangeListener { _, value ->
                if (value is Int) {
                    if (ShizukuSettings.getNightMode() != value) {
                        // An active wallpaper theme (white/black miku) forces the color scheme,
                        // so the 主题 setting only takes effect in "original" wallpaper mode.
                        val forced = ShizukuSettings.getWallpaperForcedNightMode()
                        AppCompatDelegate.setDefaultNightMode(if (forced != -1) forced else value)
                        syncDependentVisibility()
                        applyTheme(requiresRecreate = true)
                    }
                }
                true
            }
        }

        val blackNightAvailable = ShizukuSettings.getNightMode() != AppCompatDelegate.MODE_NIGHT_NO
        setChildAvailable(blackNightThemePreference, blackNightAvailable)
        blackNightThemePreference.apply {
            if (blackNightAvailable) {
                isChecked = ThemeHelper.isBlackNightTheme(context)
                setOnPreferenceChangeListener { _, _ ->
                    if (ResourceUtils.isNightMode(context.resources.configuration))
                        applyTheme(requiresRecreate = false)
                    true
                }
            }
        }

        val systemColorAvailable = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
        setChildAvailable(useSystemColorPreference, systemColorAvailable)
        useSystemColorPreference.apply {
            if (systemColorAvailable) {
                isChecked = ThemeHelper.isUsingSystemColor()
                setOnPreferenceChangeListener { _, value ->
                    if (value is Boolean) {
                        if (ThemeHelper.isUsingSystemColor() != value) {
                            customAccentPreference.isEnabled = !value
                            applyTheme(requiresRecreate = false)
                        }
                    }
                    true
                }
            }
        }

        customAccentPreference.apply {
            val isUsingSysColor = ThemeHelper.isUsingSystemColor()
            isEnabled = !isUsingSysColor
            summary = getCustomAccentSummary()
            setOnPreferenceChangeListener { _, newValue ->
                if (newValue is String) {
                    val prefs = ShizukuSettings.getPreferences()
                    if (prefs.getString("custom_accent", "DEFAULT") != newValue) {
                        prefs.edit().putString("custom_accent", newValue).apply()
                        summary = getCustomAccentSummary(newValue)
                        applyTheme(requiresRecreate = false)
                    }
                }
                true
            }
        }

        // 1b. Wallpaper theme (ShizukuX beautification): White Miku / Black Miku / Original.
        // The wallpaper setting also drives the GLOBAL color scheme so home and settings stay
        // consistent: white miku -> light everywhere, black miku -> dark everywhere,
        // original -> the user's 主题 (light/dark) setting with the stock gradient background.
        findPreference<Preference>("wallpaper_theme")?.setOnPreferenceChangeListener { _, newValue ->
            if (newValue is String && ShizukuSettings.getWallpaperTheme() != newValue) {
                ShizukuSettings.setWallpaperTheme(newValue)
                val forced = ShizukuSettings.getWallpaperForcedNightMode()
                AppCompatDelegate.setDefaultNightMode(
                    if (forced != -1) forced else ShizukuSettings.getNightMode()
                )
                // setDefaultNightMode() recreates the activity itself when the effective mode
                // changes; themeVersion++ covers the unchanged-mode case (wallpaper swap only).
                applyTheme(requiresRecreate = false)
            }
            true
        }

        // 2. M3 Expressive Controls
        expressiveShapesPreference = requireNotNull(findPreference(KEY_EXPRESSIVE_SHAPES))
        expressiveAnimationsPreference = requireNotNull(findPreference(KEY_EXPRESSIVE_ANIMATIONS))
        iconStylePreference = requireNotNull(findPreference(KEY_ICON_STYLE))
        iconColorModePreference = requireNotNull(findPreference(KEY_ICON_COLOR_MODE))
        shapeStylePreference = requireNotNull(findPreference(KEY_SHAPE_STYLE))
        animationIntensityPreference = requireNotNull(findPreference(KEY_ANIMATION_INTENSITY))

        // Only meaningful for the Two-Tone icon style - recreate() (triggered by iconStylePreference's
        // own listener below) recalculates this fresh from the persisted value on every style change.
        iconColorModePreference.isVisible = iconStylePreference.value == "twotone"

        expressiveShapesPreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        shapeStylePreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        iconStylePreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        iconColorModePreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        expressiveAnimationsPreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        animationIntensityPreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        val simulatorPref = findPreference<HomeLayoutSimulatorPreference>("home_layout_simulator")
        simulatorPref?.setFragment(this)

        val switchKeys = listOf(
            "show_start_adb_home",
            "show_terminal_home",
            "show_automation_home",
            "show_activity_log_home",
            "show_learn_more_home"
        )

        for (prefKey in switchKeys) {
            findPreference<TwoStatePreference>(prefKey)?.setOnPreferenceChangeListener { _, newValue ->
                if (newValue is Boolean) {
                    preferenceManager.sharedPreferences?.edit()?.putBoolean(prefKey, newValue)?.apply()
                    simulatorPref?.let { it.isVisible = false; it.isVisible = true }
                }
                true
            }
        }

        findPreference<TwoStatePreference>(KEY_COMPANION_MODE)?.apply {
            isChecked = ShizukuSettings.isCompanionModeEnabled()
            setOnPreferenceChangeListener { _, newValue ->
                if (newValue is Boolean) ShizukuSettings.setCompanionModeEnabled(newValue)
                true
            }
        }

        // 3. Display settings (edge-to-edge, blur)
        edgeToEdgePreference = requireNotNull(findPreference(KEY_EDGE_TO_EDGE))
        edgeToEdgePreference.isChecked = ShizukuSettings.isEdgeToEdgeEnabled()
        edgeToEdgePreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        blurUiPreference = requireNotNull(findPreference(KEY_BLUR_UI))
        blurUiPreference.isChecked = ShizukuSettings.isBlurUiEnabled()
        blurUiPreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        oneUiThemePreference = requireNotNull(findPreference(KEY_ONEUI_THEME))
        oneUiThemePreference.isChecked = ShizukuSettings.isOneUiThemeEnabled()
        oneUiThemePreference.setOnPreferenceChangeListener { _, _ ->
            applyTheme(requiresRecreate = false)
            true
        }

        // 4. Language & System
        languagePreference = requireNotNull(findPreference(KEY_LANGUAGE))
        translationPreference = requireNotNull(findPreference(KEY_TRANSLATION))

        languagePreference.setOnPreferenceChangeListener { _, newValue ->
            if (newValue is String) {
                val locale: Locale = if ("SYSTEM" == newValue) {
                    LocaleDelegate.systemLocale
                } else {
                    Locale.forLanguageTag(newValue)
                }
                // Immediate fallback in case setApplicationLocales() below doesn't trigger a
                // recreate for some reason; AppActivity.attachBaseContext() re-syncs this from
                // AppCompatDelegate on every activity creation regardless (#429), so this is
                // belt-and-suspenders, not the actual mechanism.
                LocaleDelegate.defaultLocale = locale

                // #429: setApplicationLocales() triggers its own recreate on API <33 (and a
                // config-change/recreate on 33+), so we must NOT also call
                // applyTheme(requiresRecreate = true) here — that would double-recreate the
                // activity or risk a recreate loop.
                val requested = if ("SYSTEM" == newValue) {
                    LocaleListCompat.getEmptyLocaleList()
                } else {
                    LocaleListCompat.forLanguageTags(newValue)
                }
                if (AppCompatDelegate.getApplicationLocales() != requested) {
                    AppCompatDelegate.setApplicationLocales(requested)
                } else {
                    // No-op locale change (e.g. re-selecting current language) —
                    // still apply any pending theme-only changes normally.
                    applyTheme(requiresRecreate = false)
                }
            }
            true
        }

        setupLocalePreference(languagePreference)

        translationPreference.apply {
            summary = context.getString(R.string.settings_translation_summary, context.getString(R.string.app_name))
            setOnPreferenceClickListener {
                CustomTabsHelper.launchUrlOrCopy(context, context.getString(R.string.translation_url))
                true
            }
        }
    }

    private fun syncDependentVisibility() {
        setChildAvailable(
            blackNightThemePreference,
            ShizukuSettings.getNightMode() != AppCompatDelegate.MODE_NIGHT_NO
        )
    }

    /**
     * Toggle a child's availability through its collapsible category when possible, so the
     * category's expand/collapse toggle doesn't override the condition. Falls back to a plain
     * visibility change if the child isn't inside a [CollapsiblePreferenceCategory].
     */
    private fun setChildAvailable(pref: Preference, available: Boolean) {
        val category = colorThemeCategory
        val key = pref.key
        if (category != null && key != null) {
            category.setChildAvailable(key, available)
        } else {
            pref.isVisible = available
        }
    }

    private fun setupLocalePreference(languagePreference: ListPreference) {
        val localeTags = ShizukuLocales.LOCALES
        val displayLocaleTags = ShizukuLocales.DISPLAY_LOCALES

        languagePreference.entries = displayLocaleTags
        languagePreference.entryValues = localeTags

        val currentLocaleTag = languagePreference.value
        val currentLocaleIndex = localeTags.indexOf(currentLocaleTag)
        val currentLocale = ShizukuSettings.getLocale()
        val localizedLocales = mutableListOf<CharSequence>()

        for ((index, displayLocale) in displayLocaleTags.withIndex()) {
            if (index == 0) {
                localizedLocales.add(getString(R.string.follow_system))
                continue
            }

            val locale = Locale.forLanguageTag(displayLocale.toString())
            val localeName = if (!TextUtils.isEmpty(locale.script))
                locale.getDisplayScript(locale)
            else
                locale.getDisplayName(locale)

            val localizedLocaleName = if (!TextUtils.isEmpty(locale.script))
                locale.getDisplayScript(currentLocale)
            else
                locale.getDisplayName(currentLocale)

            localizedLocales.add(
                if (index != currentLocaleIndex) {
                    "$localeName<br><small>$localizedLocaleName<small>".toHtml()
                } else {
                    localizedLocaleName
                }
            )
        }

        languagePreference.entries = localizedLocales.toTypedArray()

        languagePreference.summary = when {
            TextUtils.isEmpty(currentLocaleTag) || "SYSTEM" == currentLocaleTag -> {
                getString(R.string.follow_system)
            }
            currentLocaleIndex != -1 -> {
                val localizedLocale = localizedLocales[currentLocaleIndex]
                val newLineIndex = localizedLocale.indexOf('\n')
                if (newLineIndex == -1) {
                    localizedLocale.toString()
                } else {
                    localizedLocale.subSequence(0, newLineIndex).toString()
                }
            }
            else -> {
                ""
            }
        }
    }

    private fun getCustomAccentSummary(value: String? = null): String {
        val currentValue = value ?: ShizukuSettings.getPreferences().getString("custom_accent", "DEFAULT")
        return when (currentValue) {
            "VIOLET" -> getString(R.string.settings_accent_violet_applied)
            "GREEN" -> getString(R.string.settings_accent_green_applied)
            "CRIMSON" -> getString(R.string.settings_accent_crimson_applied)
            "OCEAN" -> getString(R.string.settings_accent_ocean_applied)
            else -> getString(R.string.settings_accent_default_applied)
        }
    }
}
